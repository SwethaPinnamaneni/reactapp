
import BasicUseState from './BasicUseState'
import ReducerExample from "./ReducerExample";
export function App() {
  return (
    <div>
     <BasicUseState/>
        <ReducerExample/>
    </div>
  );
}